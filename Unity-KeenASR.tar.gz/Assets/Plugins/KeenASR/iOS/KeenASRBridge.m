//  Created by Ognjen Todic <ogi@keenresearch.com>
//  Copyright © 2018 Keen Research LLC. All rights reserved.
//
//  Unauthorized copying of this file, via any medium is strictly prohibited
//  Proprietary and confidential

#import "KeenASR.h"

@interface KeenASRBridge:NSObject <KIOSRecognizerDelegate>

@end
static KeenASRBridge *keenASR;


@implementation KeenASRBridge
- (void)recognizerPartialResult:(KIOSResult *)result forRecognizer:(KIOSRecognizer *)recognizer {
  NSLog(@"[KeenASR-UnityBridge] Partial Result: %@ (%@), conf %@", result.cleanText, result.text, result.confidence);
  // TODO send to Unity
  UnitySendMessage("[KeenASRListener]", "PartialASRResult", result.text.UTF8String);
}


- (void)recognizerFinalResult:(KIOSResult *)result forRecognizer:(KIOSRecognizer *)recognizer {
  NSLog(@"[KeenASR-UnityBridge] Final Result: %@", result);
  UnitySendMessage("[KeenASRListener]", "FinalASRResult", [result toJSON].UTF8String);
}


 - (void)unwindAppAudioBeforeAudioInterrupt {
   NSLog(@"[KeenASR-UnityBridge]: EMPTY unwinding app audio before app goes to background");
//   UnitySendMessage("[KeenASRListener]", "UnwindAppAudioBeforeAudioInterrupt", "");
//   UnitySetAudioSessionActive(0);
//   NSLog(@"[KeenASR-UnityBridge]: done setting Unity Audio Session inactive");
}

 - (void)unwindAppAudioAfterAudioInterrupt {
   NSLog(@"[KeenASR-UnityBridge]: unwinding app audio after app goes to background");
   //   UnitySendMessage("[KeenASRListener]", "UnwindAppAudioAfterAudioInterrupt", "");
   //   UnitySetAudioSessionActive(0);
   //   NSLog(@"[KeenASR-UnityBridge]: done setting Unity Audio Session inactive");
 }

- (void)appllicationDidBecomeActiveNotificationHandler:(NSNotification *)notification {
   NSLog(@"[KeenASR-UnityBridge]: Received appllicationDidBecomeActiveNotification");
   NSLog(@"[KeenASR-UnityBridge]: Setting Unity Audio Session active");
   UnitySetAudioSessionActive(1);
   NSLog(@"[KeenASR-UnityBridge]: Reinitializing KeenASR audio stack");
   [[KIOSRecognizer sharedInstance] reinitAudioStack];
   UnitySendMessage("[KeenASRListener]", "RecognizerReadyToListenAfterInterrupt", "");
}

- (void)appllicationWillResignActiveNotificationHandler:(NSNotification *)notification {
   NSLog(@"[KeenASR-UnityBridge]: Received appllicationWillResignActiveNotification");
   NSLog(@"[KeenASR-UnityBridge]: Deactivating KeenASR audio stack");
   [[KIOSRecognizer sharedInstance] deactivateAudioStack];
   NSLog(@"[KeenASR-UnityBridge]: Setting Unity Audio Session inactive");
   UnitySetAudioSessionActive(0);
   NSLog(@"[KeenASR-UnityBridge]: done setting Unity Audio Session inactive");
}

/*
- (void)setupAppAudioAfterInterrupt {
  NSLog(@"[KeenASR-UnityBridge]: setupAppAudioAfterInterrupt"); 
  NSLog(@"[KeenASR-UnityBridge]: Un-pausing Unity");
  //UnityPause(0);
  //  NSLog(@"[KeenASR-UnityBridge]: activating Unity audio session");
  UnitySetAudioSessionActive(1);
  NSLog(@"[KeenASR-UnityBridge]: activated Unity audio session in setupAppAudioAfterInterrupt");
}
*/

- (void)recognizerReadyToListenAfterInterrupt:(nonnull KIOSRecognizer *)recognizer {
  NSLog(@"[KeenASR-UnityBridge]: Received recognizerReadyToListenAfterInterrupt, passing up");
  UnitySendMessage("[KeenASRListener]", "RecognizerReadyToListenAfterInterrupt", "");
}

@end



extern void _SetLogLevel (int logLevel) {
  if (logLevel != KIOSRecognizerLogLevelDebug &&
      logLevel != KIOSRecognizerLogLevelInfo &&
      logLevel != KIOSRecognizerLogLevelWarning) {
    NSLog(@"[KeenASR-UnityBridge] Unknown log level %d", logLevel);
    return;
  }
  NSLog(@"[KeenASR-UnityBridge] Setting log level to %d", logLevel);  
  [KIOSRecognizer setLogLevel:(KIOSRecognizerLogLevel)logLevel];
}


extern void _Init(const char* bundleName) {
  if ([KIOSRecognizer sharedInstance]) {
    NSLog(@"[KeenASR-UnityBridge]Recognizer already initialized");
    return;
  } 
  NSString *bn = [NSString stringWithUTF8String:bundleName];
  NSLog(@"[KeenASR-UnityBridge] Initializing ASR engine with bundle %@", bn);
  
  NSString *bundlePath = [[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"Data/Raw"] stringByAppendingPathComponent:bn];
  NSLog(@"[KeenASR-UnityBridge] Initializing recognizer with asr bundle at path %@", bundlePath);
  if ([KIOSRecognizer initWithASRBundleAtPath:bundlePath]) {
    NSLog(@"[KeenASR-UnityBridge] Succesfully initialized recognizer with the bundle %@", bn);
    keenASR = [KeenASRBridge new];
    [KIOSRecognizer sharedInstance].delegate = keenASR;
    [KIOSRecognizer sharedInstance].handleNotifications = false;
    
    [[NSNotificationCenter defaultCenter] addObserver:keenASR selector:@selector(appllicationWillResignActiveNotificationHandler:) name:UIApplicationWillResignActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:keenASR selector:@selector(appllicationDidBecomeActiveNotificationHandler:) name:UIApplicationDidBecomeActiveNotification object:nil];
  } else {
    NSLog(@"[KeenASR-UnityBridge] Unable to initialized recognizer with the bundle %@", bn);
  }
  if ([KIOSRecognizer sharedInstance])
    UnitySendMessage("[KeenASRListener]", "Initialized", "1");
  else
    UnitySendMessage("[KeenASRListener]", "Initialized", "0");
}

extern bool _CreateCustomDecodingGraphFromSentences(const char* _dgName, const char** _phrases, int numPhrases) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Initialize prior to this??");
    return false;
  }
  NSString *dgName = [NSString stringWithUTF8String:_dgName];
  NSMutableArray *phrases = [NSMutableArray new];
  NSLog(@"[KeenASR-UnityBridge] Creating decoding graph using %d phrases", numPhrases);
  for (int i=0; i<numPhrases; i++) {
    [phrases addObject:[NSString stringWithUTF8String:_phrases[i]]];
  }
  if (! [KIOSDecodingGraph createDecodingGraphFromSentences:phrases
					    forRecognizer:recognizer
					  andSaveWithName:dgName]) {
    NSLog(@"[KeenASR-UnityBridge] Unable to create decoding graph %@", dgName);
    return false;
  }

  return true;
}

// todo existance of the graph

extern bool _PrepareForListeningWithCustomDecodingGraph(const char* _dgName) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Inititialize prior to this??");
    return false;
  }

  NSString *dgName = [NSString stringWithUTF8String:_dgName];
 
  if (! [recognizer prepareForListeningWithCustomDecodingGraphWithName:dgName]) {
    NSLog(@"[KeenASR-UnityBridge] Unable to prepare for listening with decoding graph %@", dgName);
    return false;
  }

  return true;
}


extern bool _CustomDecodingGraphWithNameExists(const char* _dgName) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Inititialize prior to this??");
    return false;
  }

  NSString *dgName = [NSString stringWithUTF8String:_dgName];

  return [KIOSDecodingGraph decodingGraphWithNameExists:dgName
					  forRecognizer:recognizer];
}


extern bool _StartListening() {
  if (! [[KIOSRecognizer sharedInstance] startListening]) {
    NSLog(@"[KeenASR-UnityBridge] Unable to start listening");
    return false;
  }
  
  NSLog(@"[KeenASR-UnityBridge] Starting to listen");
  return true;
}


extern void _StopListening() {
  [[KIOSRecognizer sharedInstance] stopListening];
  NSLog(@"[KeenASR-UnityBridge] Stopped listening");
}


extern bool _IsListening() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge:_isListening] WARN: no recognizer setup");
    return false;
  }

  return (recognizer.recognizerState == KIOSRecognizerStateListening || recognizer.recognizerState == KIOSRecognizerStateFinalProcessing);
}


extern float _InputLevel() {
 KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
 if (!recognizer) {
    NSLog(@"[KeenASR-UnityBridge:_inputLevel] WARN: no recognizer setup");
    return 0.0;
  }
 if (recognizer.recognizerState != KIOSRecognizerStateListening) {
    NSLog(@"[KeenASR-UnityBridge:_peakValue] WARN: recognizer is not listening");
    return 0.0;
  }
 return [recognizer inputLevel];
}


// adaptation
// - (void)adaptToSpeakerWithName:(nonnull NSString *)speakerName;
extern void _AdaptToSpeakerWithName(const char *speakerName) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_adaptToSpeakerWithName] WARN: no recognizer setup");
     return;
  }

  NSString *name = [NSString stringWithUTF8String:speakerName];
  [recognizer adaptToSpeakerWithName:name];
}

// - (void)resetSpeakerAdaptation;
extern void _ResetSpeakerAdaptation() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_resetSpeakerAdaptation] WARN: no recognizer setup");
     return;
  }
  [recognizer resetSpeakerAdaptation];
}

// - (void)saveSpeakerAdaptationProfile;
extern void _SaveSpeakerAdaptationProfile() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_saveSpeakerAdaptationProfile] WARN: no recognizer setup");
     return;
  }
  [recognizer saveSpeakerAdaptationProfile];
}

// + (BOOL)removeAllSpeakerAdaptationProfiles;
extern bool _RemoveAllSpeakerAdaptationProfiles() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_removeAllSpeakerAdaptationProfiles] WARN: no recognizer setup");
     return false;
   }
  return [KIOSRecognizer removeAllSpeakerAdaptationProfiles];
}

// + (BOOL)removeSpeakerAdaptationProfiles:(nonnull NSString *)speakerName;
extern bool _RemoveSpeakerAdaptationProfiles(const char *speakerName) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_removeSpeakerAdaptationProfiles] WARN: no recognizer setup");
     return false;
  }

  NSString *name = [NSString stringWithUTF8String:speakerName];
  return [KIOSRecognizer removeSpeakerAdaptationProfiles:name];
}


// File recording 
// @property(nonatomic, assign) BOOL createAudioRecordings;
extern void _SetCreateAudioRecordings(bool value) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_setCreateAudioRecordings] WARN: no recognizer setup");
     return;
   }

   recognizer.createAudioRecordings = value;
}



extern const char * _GetRecordingsDir() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_getRecordingDir] WARN: no recognizer setup");
     return NULL;
  }

  if (recognizer.recordingsDir)
    return recognizer.recordingsDir.UTF8String;

  return NULL;
}


// /** Filename of the last recording. If createAudioRecordings was set to TRUE, you
//  can read the filename of the latest recording via this property. */
// @property(nonatomic, readonly, nullable) NSString *lastRecordingFilename;
extern const char * _GetLastRecordingFilename() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (!recognizer) {
     NSLog(@"[KeenASR-UnityBridge:_getLastRecordingFilename] WARN: no recognizer setup");
     return NULL;
  }
  if (recognizer.lastRecordingFilename)
    return recognizer.lastRecordingFilename.UTF8String;

  return NULL;
}




extern bool _SetVADParameter(int vadParameter, float value) {
  NSLog(@"[KeenASR-UnityBridge] Setting VAD parameter (%d) to value %f", vadParameter, value);
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Inititialize prior to this??");
    return false;
  }

  [recognizer setVADParameter:(KIOSVadParameter)vadParameter toValue:value];

  return true;
}


extern void _PerformEchoCancellation(bool value) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Inititialize prior to this??");
  }
  [recognizer performEchoCancellation: value];
}


extern int _GetRecognizerState() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Inititialize prior to this??");
    return -1;
  }
  return recognizer.recognizerState;
}



extern bool _IsEchoCancellationAvailable() {
  return [KIOSRecognizer echoCancellationAvailable];
}


extern void _SetCreateJSONMetadata (value) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Inititialize prior to calling SetCreateJSONMetadata?");
    return;
  }
  recognizer.createJSONMetadata = value;

}

extern const char * _GetLastJSONMetadataFilename() {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  if (! recognizer) {
    NSLog(@"[KeenASR-UnityBridge] Unable to retrieve recognizer. Did you call Inititialize prior to calling SetCreateJSONMetadata?");
    return NULL;
  }
  if (recognizer.lastJSONMetadataFilename)
    return recognizer.lastJSONMetadataFilename.UTF8String;

  return NULL;
}




// KIOS Uploader

extern bool _CreateDataUploadThread(const char *appKey_) {
  KIOSRecognizer *recognizer = [KIOSRecognizer sharedInstance];
  NSString *appKey = [NSString stringWithUTF8String:appKey_];
  return [KIOSUploader createDataUploadThreadForRecognizer:recognizer usingAppKey:appKey];
}


extern void _SetRemoveDataAfterUpload (bool value) {
  KIOSUploader.removeDataAfterUpload = value;
}


extern void _PauseUpload () {
  [KIOSUploader pause];
}


extern bool _ResumeUpload () {
  return [KIOSUploader resume];
}


extern bool _IsUploadPaused () {
  return [KIOSUploader isPaused];
}
